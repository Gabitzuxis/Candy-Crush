import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  MessageSquare, 
  Send, 
  Trash2, 
  Download,
  ArrowDown,
  Filter,
  Terminal
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import type { ChatMessage } from "@shared/schema";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ChatConsoleProps {
  messages: ChatMessage[];
  onSendCommand: (command: string) => void;
  onClear: () => void;
  isConnected: boolean;
}

export function ChatConsole({ messages, onSendCommand, onClear, isConnected }: ChatConsoleProps) {
  const [command, setCommand] = useState("");
  const [filter, setFilter] = useState<"all" | "chat" | "system">("all");
  const [autoScroll, setAutoScroll] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  const filteredMessages = messages.filter((msg) => {
    if (filter === "all") return true;
    if (filter === "chat") return msg.type === "chat" || msg.type === "whisper";
    if (filter === "system") return msg.type === "system";
    return true;
  });

  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, autoScroll]);

  const handleSend = () => {
    if (command.trim() && isConnected) {
      onSendCommand(command);
      setCommand("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString("en-US", { 
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  };

  const getMessageColor = (type: ChatMessage["type"]) => {
    switch (type) {
      case "system":
        return "text-amber-400";
      case "whisper":
        return "text-purple-400";
      case "action":
        return "text-cyan-400";
      case "chat":
      default:
        return "text-foreground";
    }
  };

  const exportLogs = () => {
    const content = messages
      .map((msg) => `[${formatTimestamp(msg.timestamp)}] <${msg.sender}> ${msg.message}`)
      .join("\n");
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `chat-log-${new Date().toISOString().split("T")[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-600/20 to-cyan-600/20 flex items-center justify-center">
            <Terminal className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <CardTitle className="text-lg">Chat Console</CardTitle>
            <p className="text-xs text-muted-foreground">
              {messages.length} messages
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
            <SelectTrigger className="w-32" data-testid="select-chat-filter">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="chat">Chat</SelectItem>
              <SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setAutoScroll(!autoScroll)}
            className={autoScroll ? "text-emerald-400" : ""}
            data-testid="button-auto-scroll"
          >
            <ArrowDown className="w-4 h-4" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={exportLogs}
            data-testid="button-export-logs"
          >
            <Download className="w-4 h-4" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onClear}
            data-testid="button-clear-chat"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
        <ScrollArea 
          ref={scrollRef}
          className="flex-1 p-4"
        >
          <div className="space-y-1 font-mono text-sm">
            <AnimatePresence initial={false}>
              {filteredMessages.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center h-48 text-muted-foreground"
                >
                  <MessageSquare className="w-12 h-12 mb-4 opacity-20" />
                  <p>No messages yet</p>
                  <p className="text-xs mt-1">Messages will appear here when connected</p>
                </motion.div>
              ) : (
                filteredMessages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    className={`flex gap-2 py-0.5 ${getMessageColor(msg.type)}`}
                  >
                    <span className="text-muted-foreground shrink-0">
                      [{formatTimestamp(msg.timestamp)}]
                    </span>
                    <span className="text-cyan-400 shrink-0">
                      &lt;{msg.sender}&gt;
                    </span>
                    <span className="break-all">{msg.message}</span>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </ScrollArea>

        <div className="p-4 border-t border-border">
          <div className="flex gap-2">
            <Input
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={isConnected ? "Type a command or message..." : "Connect to send messages"}
              disabled={!isConnected}
              className="flex-1 font-mono"
              data-testid="input-chat-command"
            />
            <Button 
              onClick={handleSend}
              disabled={!isConnected || !command.trim()}
              className="bg-gradient-to-r from-emerald-600 to-cyan-600"
              data-testid="button-send-command"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
