import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { 
  User, 
  Server, 
  Shield, 
  Globe,
  RefreshCw,
  Terminal,
  Loader2,
  Gamepad2
} from "lucide-react";
import { MINECRAFT_VERSIONS, type MinecraftAccount, insertAccountSchema } from "@shared/schema";
import { motion } from "framer-motion";

const formSchema = insertAccountSchema.extend({
  username: z.string().min(1, "Username is required").max(16, "Username max 16 characters"),
  serverHost: z.string().optional(),
  serverPort: z.coerce.number().min(1).max(65535).default(25565),
  proxyHost: z.string().optional(),
  proxyPort: z.coerce.number().min(1).max(65535).optional(),
  reconnectDelay: z.coerce.number().min(1000).max(300000).default(5000),
  autoCommands: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

interface AccountFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  account?: MinecraftAccount | null;
  onSubmit: (data: FormData) => void;
  isLoading?: boolean;
}

export function AccountForm({ open, onOpenChange, account, onSubmit, isLoading }: AccountFormProps) {
  const isEditing = !!account;

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: account?.username || "",
      accountType: account?.accountType || "offline",
      version: account?.version || "1.20.4",
      serverHost: account?.serverHost || "",
      serverPort: account?.serverPort || 25565,
      proxyEnabled: account?.proxyEnabled || false,
      proxyHost: account?.proxyHost || "",
      proxyPort: account?.proxyPort || undefined,
      proxyType: account?.proxyType || "socks5",
      autoReconnect: account?.autoReconnect ?? true,
      reconnectDelay: account?.reconnectDelay || 5000,
      autoCommands: account?.autoCommands?.join("\n") || "",
      acceptTextures: account?.acceptTextures ?? true,
    },
  });

  const handleSubmit = (data: FormData) => {
    const processedData = {
      ...data,
      autoCommands: data.autoCommands 
        ? data.autoCommands.split("\n").filter(cmd => cmd.trim())
        : [],
    };
    onSubmit(processedData as any);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <motion.div
              className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-600 to-cyan-600 flex items-center justify-center"
              animate={{ 
                boxShadow: ["0 0 15px rgba(34, 197, 94, 0.3)", "0 0 25px rgba(34, 197, 94, 0.5)", "0 0 15px rgba(34, 197, 94, 0.3)"]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Gamepad2 className="w-5 h-5 text-white" />
            </motion.div>
            {isEditing ? "Edit Account" : "Add New Account"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Username
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Steve" 
                        {...field} 
                        data-testid="input-username"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="accountType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Shield className="w-4 h-4" />
                      Account Type
                    </FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-account-type">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="offline">Offline (Cracked)</SelectItem>
                        <SelectItem value="online">Online (Microsoft)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="version"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Minecraft Version</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-version">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="max-h-64">
                        {MINECRAFT_VERSIONS.map((version) => (
                          <SelectItem key={version} value={version}>
                            {version}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="serverHost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Server className="w-4 h-4" />
                      Server Address
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="mc.server.com" 
                        {...field} 
                        data-testid="input-server-host"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="serverPort"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Server Port</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="25565" 
                      {...field} 
                      data-testid="input-server-port"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Accordion type="multiple" className="w-full">
              <AccordionItem value="proxy">
                <AccordionTrigger className="text-sm">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    Proxy Settings
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="proxyEnabled"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel>Enable Proxy</FormLabel>
                          <FormDescription>
                            Route connection through a proxy server
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="switch-proxy-enabled"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {form.watch("proxyEnabled") && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-4"
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="proxyType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Proxy Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-proxy-type">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="socks5">SOCKS5</SelectItem>
                                  <SelectItem value="http">HTTP</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="proxyHost"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Proxy Host</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="127.0.0.1" 
                                  {...field} 
                                  data-testid="input-proxy-host"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="proxyPort"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Proxy Port</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="1080" 
                                {...field} 
                                data-testid="input-proxy-port"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </motion.div>
                  )}
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="reconnect">
                <AccordionTrigger className="text-sm">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Auto-Reconnect Settings
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="autoReconnect"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel>Auto-Reconnect</FormLabel>
                          <FormDescription>
                            Automatically reconnect when disconnected
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="switch-auto-reconnect"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {form.watch("autoReconnect") && (
                    <FormField
                      control={form.control}
                      name="reconnectDelay"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Reconnect Delay (ms)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="5000" 
                              {...field} 
                              data-testid="input-reconnect-delay"
                            />
                          </FormControl>
                          <FormDescription>
                            Delay before attempting to reconnect (1000-300000ms)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="commands">
                <AccordionTrigger className="text-sm">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4" />
                    Auto Commands
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="autoCommands"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Commands to Execute on Join</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={"/login password\n/register password password\n/hub"}
                            className="font-mono min-h-32"
                            {...field}
                            data-testid="textarea-auto-commands"
                          />
                        </FormControl>
                        <FormDescription>
                          One command per line. Will execute in order after connecting.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="textures">
                <AccordionTrigger className="text-sm">
                  <div className="flex items-center gap-2">
                    <Gamepad2 className="w-4 h-4" />
                    Resource Packs
                  </div>
                </AccordionTrigger>
                <AccordionContent className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="acceptTextures"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel>Accept Resource Packs</FormLabel>
                          <FormDescription>
                            Automatically accept server resource packs
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="switch-accept-textures"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="ghost"
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading}
                className="bg-gradient-to-r from-emerald-600 to-cyan-600"
                data-testid="button-save-account"
              >
                {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {isEditing ? "Save Changes" : "Add Account"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
