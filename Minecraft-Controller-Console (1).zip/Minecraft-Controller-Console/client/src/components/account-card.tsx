import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Square, 
  Settings2, 
  Trash2, 
  Globe, 
  Shield, 
  Wifi,
  WifiOff,
  Loader2,
  RefreshCw
} from "lucide-react";
import { motion } from "framer-motion";
import type { MinecraftAccount, ConnectionStatus } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface AccountCardProps {
  account: MinecraftAccount;
  onLaunch: (id: string) => void;
  onStop: (id: string) => void;
  onEdit: (account: MinecraftAccount) => void;
  onDelete: (id: string) => void;
}

export function AccountCard({ account, onLaunch, onStop, onEdit, onDelete }: AccountCardProps) {
  const isConnected = account.connectionStatus === "connected";
  const isConnecting = account.connectionStatus === "connecting" || 
                       account.connectionStatus === "reconnecting";

  const getStatusColor = (status: ConnectionStatus) => {
    switch (status) {
      case "connected":
        return "bg-emerald-500";
      case "connecting":
        return "bg-amber-500";
      case "reconnecting":
        return "bg-amber-500";
      case "disconnected":
      default:
        return "bg-gray-500";
    }
  };

  const getStatusIcon = (status: ConnectionStatus) => {
    switch (status) {
      case "connected":
        return <Wifi className="w-3 h-3" />;
      case "connecting":
      case "reconnecting":
        return <Loader2 className="w-3 h-3 animate-spin" />;
      case "disconnected":
      default:
        return <WifiOff className="w-3 h-3" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="relative overflow-visible group">
        <motion.div
          className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none"
          style={{
            background: "linear-gradient(135deg, rgba(34, 197, 94, 0.1), rgba(6, 182, 212, 0.1))",
          }}
          transition={{ duration: 0.3 }}
        />
        
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
          <div className="flex items-center gap-3">
            <Avatar className="w-12 h-12 border-2 border-primary/20">
              <AvatarFallback className="bg-gradient-to-br from-emerald-600 to-cyan-600 text-white font-bold">
                {account.username.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-lg" data-testid={`text-account-name-${account.id}`}>
                {account.username}
              </h3>
              <div className="flex items-center gap-2 mt-0.5">
                <Badge 
                  variant={account.accountType === "online" ? "default" : "secondary"}
                  className="text-xs"
                >
                  {account.accountType === "online" ? (
                    <Shield className="w-3 h-3 mr-1" />
                  ) : (
                    <Globe className="w-3 h-3 mr-1" />
                  )}
                  {account.accountType}
                </Badge>
                <span className="text-xs text-muted-foreground">v{account.version}</span>
              </div>
            </div>
          </div>

          <motion.div 
            className={`flex items-center gap-1.5 px-2 py-1 rounded-full ${getStatusColor(account.connectionStatus)} bg-opacity-20`}
            animate={isConnected ? { 
              boxShadow: ["0 0 0px rgba(34, 197, 94, 0)", "0 0 10px rgba(34, 197, 94, 0.5)", "0 0 0px rgba(34, 197, 94, 0)"]
            } : {}}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <motion.div 
              className={`w-2 h-2 rounded-full ${getStatusColor(account.connectionStatus)}`}
              animate={isConnected ? { scale: [1, 1.2, 1] } : {}}
              transition={{ duration: 1, repeat: Infinity }}
            />
            {getStatusIcon(account.connectionStatus)}
          </motion.div>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Globe className="w-4 h-4" />
              <span className="truncate">
                {account.serverHost || "No server set"}
              </span>
            </div>
            {account.proxyEnabled && (
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  <RefreshCw className="w-3 h-3 mr-1" />
                  Proxy
                </Badge>
              </div>
            )}
            {account.autoReconnect && (
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400/30">
                  <RefreshCw className="w-3 h-3 mr-1" />
                  Auto-Reconnect
                </Badge>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 pt-2">
            {isConnected || isConnecting ? (
              <Button 
                variant="destructive" 
                className="flex-1"
                onClick={() => onStop(account.id)}
                disabled={isConnecting}
                data-testid={`button-stop-${account.id}`}
              >
                {isConnecting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Square className="w-4 h-4 mr-2" />
                )}
                {isConnecting ? "Connecting..." : "Stop"}
              </Button>
            ) : (
              <Button 
                className="flex-1 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500"
                onClick={() => onLaunch(account.id)}
                data-testid={`button-launch-${account.id}`}
              >
                <Play className="w-4 h-4 mr-2" />
                Launch
              </Button>
            )}
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => onEdit(account)}
                  data-testid={`button-edit-${account.id}`}
                >
                  <Settings2 className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Edit Account</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => onDelete(account.id)}
                  data-testid={`button-delete-${account.id}`}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Delete Account</TooltipContent>
            </Tooltip>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
