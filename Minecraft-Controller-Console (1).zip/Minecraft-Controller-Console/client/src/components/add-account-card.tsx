import { Card } from "@/components/ui/card";
import { Plus, Gamepad2 } from "lucide-react";
import { motion } from "framer-motion";

interface AddAccountCardProps {
  onClick: () => void;
}

export function AddAccountCard({ onClick }: AddAccountCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
    >
      <Card
        onClick={onClick}
        className="relative h-full min-h-[200px] border-2 border-dashed border-muted-foreground/20 bg-transparent cursor-pointer group overflow-visible"
        data-testid="button-add-account"
      >
        <motion.div
          className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none"
          style={{
            background: "linear-gradient(135deg, rgba(34, 197, 94, 0.05), rgba(6, 182, 212, 0.05))",
          }}
          transition={{ duration: 0.3 }}
        />
        
        <div className="flex flex-col items-center justify-center h-full gap-4 p-6">
          <motion.div
            className="w-16 h-16 rounded-xl bg-muted/50 flex items-center justify-center group-hover:bg-gradient-to-br group-hover:from-emerald-600/20 group-hover:to-cyan-600/20 transition-all duration-300"
            whileHover={{ 
              boxShadow: "0 0 30px rgba(34, 197, 94, 0.3)"
            }}
          >
            <Plus className="w-8 h-8 text-muted-foreground group-hover:text-emerald-400 transition-colors" />
          </motion.div>
          <div className="text-center">
            <p className="font-medium text-muted-foreground group-hover:text-foreground transition-colors">
              Add Account
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Connect a new Minecraft account
            </p>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
