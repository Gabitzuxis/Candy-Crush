import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { 
  LayoutDashboard, 
  Users, 
  MessageSquare, 
  Settings,
  Gamepad2,
  Wifi,
  WifiOff,
  Loader2
} from "lucide-react";
import { motion } from "framer-motion";
import type { ConnectionStatus } from "@shared/schema";

const menuItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Accounts", url: "/accounts", icon: Users },
  { title: "Chat Viewer", url: "/chat", icon: MessageSquare },
  { title: "Settings", url: "/settings", icon: Settings },
];

interface AppSidebarProps {
  connectionStatus?: ConnectionStatus;
  connectedAccounts?: number;
}

export function AppSidebar({ connectionStatus = "disconnected", connectedAccounts = 0 }: AppSidebarProps) {
  const [location] = useLocation();

  const getStatusColor = () => {
    switch (connectionStatus) {
      case "connected":
        return "bg-emerald-500";
      case "connecting":
      case "reconnecting":
        return "bg-amber-500";
      case "disconnected":
      default:
        return "bg-gray-500";
    }
  };

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case "connected":
        return <Wifi className="w-4 h-4" />;
      case "connecting":
      case "reconnecting":
        return <Loader2 className="w-4 h-4 animate-spin" />;
      case "disconnected":
      default:
        return <WifiOff className="w-4 h-4" />;
    }
  };

  const getStatusText = () => {
    switch (connectionStatus) {
      case "connected":
        return `${connectedAccounts} Connected`;
      case "connecting":
        return "Connecting...";
      case "reconnecting":
        return "Reconnecting...";
      case "disconnected":
      default:
        return "Disconnected";
    }
  };

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <motion.div
            className="relative"
            animate={{ 
              boxShadow: ["0 0 20px rgba(34, 197, 94, 0.3)", "0 0 40px rgba(34, 197, 94, 0.5)", "0 0 20px rgba(34, 197, 94, 0.3)"]
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center">
              <Gamepad2 className="w-6 h-6 text-white" />
            </div>
          </motion.div>
          <div>
            <h1 className="font-bold text-lg tracking-tight">MC Console</h1>
            <p className="text-xs text-muted-foreground">Launcher v1.0</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs uppercase tracking-wider text-muted-foreground">
            Navigation
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => {
                const isActive = location === item.url || 
                  (item.url !== "/" && location.startsWith(item.url));
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      data-testid={`nav-${item.title.toLowerCase()}`}
                    >
                      <Link href={item.url} className="flex items-center gap-3">
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <motion.div 
          className="flex items-center gap-3 p-3 rounded-lg bg-card/50 border border-card-border"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <motion.div 
            className={`w-2.5 h-2.5 rounded-full ${getStatusColor()}`}
            animate={connectionStatus === "connected" ? {
              scale: [1, 1.2, 1],
              opacity: [1, 0.8, 1]
            } : {}}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <div className="flex items-center gap-2 flex-1">
            {getStatusIcon()}
            <span className="text-sm font-medium">{getStatusText()}</span>
          </div>
        </motion.div>
      </SidebarFooter>
    </Sidebar>
  );
}
