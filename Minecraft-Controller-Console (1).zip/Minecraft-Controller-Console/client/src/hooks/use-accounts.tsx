import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { MinecraftAccount, InsertAccount } from "@shared/schema";

export function useAccounts() {
  const { toast } = useToast();

  const { data: accounts = [], isLoading } = useQuery<MinecraftAccount[]>({
    queryKey: ["/api/accounts"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertAccount) => {
      const res = await apiRequest("POST", "/api/accounts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: "Account created",
        description: "Your new account has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create account",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: MinecraftAccount) => {
      const res = await apiRequest("PATCH", `/api/accounts/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: "Account updated",
        description: "Your account has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update account",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/accounts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: "Account deleted",
        description: "The account has been removed.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete account",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const launchMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/accounts/${id}/launch`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: "Launching...",
        description: "Connecting to the server.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to launch",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const stopMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/accounts/${id}/stop`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: "Disconnected",
        description: "The account has been disconnected.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to stop",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createAccount = useCallback((data: InsertAccount) => {
    return createMutation.mutateAsync(data);
  }, [createMutation]);

  const updateAccount = useCallback((data: MinecraftAccount) => {
    return updateMutation.mutateAsync(data);
  }, [updateMutation]);

  const deleteAccount = useCallback((id: string) => {
    return deleteMutation.mutateAsync(id);
  }, [deleteMutation]);

  const launchAccount = useCallback((id: string) => {
    return launchMutation.mutateAsync(id);
  }, [launchMutation]);

  const stopAccount = useCallback((id: string) => {
    return stopMutation.mutateAsync(id);
  }, [stopMutation]);

  return {
    accounts,
    isLoading,
    createAccount,
    updateAccount,
    deleteAccount,
    launchAccount,
    stopAccount,
    isCreating: createMutation.isPending,
    isUpdating: updateMutation.isPending,
    isDeleting: deleteMutation.isPending,
    isLaunching: launchMutation.isPending,
    isStopping: stopMutation.isPending,
  };
}
