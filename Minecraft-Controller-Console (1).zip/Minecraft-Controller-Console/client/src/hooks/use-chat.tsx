import { useState, useEffect, useCallback, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import type { ChatMessage } from "@shared/schema";

export function useChat() {
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const connect = () => {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.type === "chat") {
            const message: ChatMessage = {
              id: crypto.randomUUID(),
              accountId: data.accountId,
              timestamp: data.timestamp || Date.now(),
              sender: data.sender || "System",
              message: data.message,
              type: data.messageType || "chat",
            };
            setMessages((prev) => [...prev, message]);
          } else if (data.type === "status") {
            if (data.status === "connected") {
              toast({
                title: "Connected",
                description: `${data.username} connected to ${data.server}`,
              });
            } else if (data.status === "disconnected") {
              toast({
                title: "Disconnected",
                description: data.reason || "Connection lost",
                variant: "destructive",
              });
            }
          }
        } catch (e) {
          console.error("Failed to parse WebSocket message:", e);
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        setTimeout(connect, 3000);
      };

      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
      };
    };

    connect();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [toast]);

  const sendCommand = useCallback((command: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && selectedAccountId) {
      wsRef.current.send(JSON.stringify({
        type: "command",
        accountId: selectedAccountId,
        command,
      }));

      const localMessage: ChatMessage = {
        id: crypto.randomUUID(),
        accountId: selectedAccountId,
        timestamp: Date.now(),
        sender: "You",
        message: command,
        type: "chat",
      };
      setMessages((prev) => [...prev, localMessage]);
    }
  }, [selectedAccountId]);

  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  return {
    messages,
    sendCommand,
    clearMessages,
    isConnected,
    selectedAccountId,
    setSelectedAccountId,
  };
}
