import { useState } from "react";
import { AccountCard } from "@/components/account-card";
import { AddAccountCard } from "@/components/add-account-card";
import { AccountForm } from "@/components/account-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Search,
  Filter,
  Users,
  Wifi,
  WifiOff,
  SortAsc
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { useAccounts } from "@/hooks/use-accounts";
import type { MinecraftAccount } from "@shared/schema";

export default function Accounts() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<MinecraftAccount | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "connected" | "disconnected">("all");
  const [sortBy, setSortBy] = useState<"name" | "status">("name");

  const { 
    accounts, 
    createAccount, 
    updateAccount, 
    deleteAccount,
    launchAccount,
    stopAccount,
    isCreating,
    isUpdating 
  } = useAccounts();

  const filteredAccounts = accounts
    .filter((account) => {
      const matchesSearch = account.username.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = 
        statusFilter === "all" ||
        (statusFilter === "connected" && account.connectionStatus === "connected") ||
        (statusFilter === "disconnected" && account.connectionStatus === "disconnected");
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === "name") {
        return a.username.localeCompare(b.username);
      }
      const statusOrder = { connected: 0, connecting: 1, reconnecting: 2, disconnected: 3 };
      return statusOrder[a.connectionStatus] - statusOrder[b.connectionStatus];
    });

  const connectedCount = accounts.filter(a => a.connectionStatus === "connected").length;

  const handleEdit = (account: MinecraftAccount) => {
    setEditingAccount(account);
    setIsFormOpen(true);
  };

  const handleFormSubmit = async (data: any) => {
    if (editingAccount) {
      await updateAccount({ ...data, id: editingAccount.id });
    } else {
      await createAccount(data);
    }
    setIsFormOpen(false);
    setEditingAccount(null);
  };

  const handleFormClose = (open: boolean) => {
    setIsFormOpen(open);
    if (!open) {
      setEditingAccount(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Accounts</h1>
          <p className="text-muted-foreground mt-1">
            Manage all your Minecraft accounts
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="px-3 py-1">
            <Users className="w-4 h-4 mr-2" />
            {accounts.length} Total
          </Badge>
          <Badge 
            variant={connectedCount > 0 ? "default" : "secondary"} 
            className="px-3 py-1"
          >
            <Wifi className="w-4 h-4 mr-2" />
            {connectedCount} Connected
          </Badge>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search accounts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-accounts"
          />
        </div>

        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
          <SelectTrigger className="w-40" data-testid="select-status-filter">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="connected">
              <div className="flex items-center gap-2">
                <Wifi className="w-4 h-4 text-emerald-500" />
                Connected
              </div>
            </SelectItem>
            <SelectItem value="disconnected">
              <div className="flex items-center gap-2">
                <WifiOff className="w-4 h-4 text-gray-500" />
                Disconnected
              </div>
            </SelectItem>
          </SelectContent>
        </Select>

        <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
          <SelectTrigger className="w-36" data-testid="select-sort">
            <SortAsc className="w-4 h-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">By Name</SelectItem>
            <SelectItem value="status">By Status</SelectItem>
          </SelectContent>
        </Select>

        <Button 
          onClick={() => setIsFormOpen(true)}
          className="bg-gradient-to-r from-emerald-600 to-cyan-600"
          data-testid="button-add-new-account"
        >
          Add Account
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <AnimatePresence>
          {filteredAccounts.map((account) => (
            <AccountCard
              key={account.id}
              account={account}
              onLaunch={launchAccount}
              onStop={stopAccount}
              onEdit={handleEdit}
              onDelete={deleteAccount}
            />
          ))}
        </AnimatePresence>
        <AddAccountCard onClick={() => setIsFormOpen(true)} />
      </div>

      {filteredAccounts.length === 0 && accounts.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <p className="text-muted-foreground">No accounts match your filters</p>
          <Button 
            variant="ghost" 
            className="mt-2"
            onClick={() => {
              setSearchQuery("");
              setStatusFilter("all");
            }}
          >
            Clear filters
          </Button>
        </motion.div>
      )}

      <AccountForm
        open={isFormOpen}
        onOpenChange={handleFormClose}
        account={editingAccount}
        onSubmit={handleFormSubmit}
        isLoading={isCreating || isUpdating}
      />
    </div>
  );
}
