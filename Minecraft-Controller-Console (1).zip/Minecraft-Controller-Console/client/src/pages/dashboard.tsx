import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AccountCard } from "@/components/account-card";
import { AddAccountCard } from "@/components/add-account-card";
import { AccountForm } from "@/components/account-form";
import { ChatConsole } from "@/components/chat-console";
import { 
  Users, 
  MessageSquare, 
  Wifi, 
  Activity,
  Zap,
  TrendingUp
} from "lucide-react";
import { motion } from "framer-motion";
import { useAccounts } from "@/hooks/use-accounts";
import { useChat } from "@/hooks/use-chat";
import type { MinecraftAccount } from "@shared/schema";

export default function Dashboard() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<MinecraftAccount | null>(null);
  
  const { 
    accounts, 
    createAccount, 
    updateAccount, 
    deleteAccount,
    launchAccount,
    stopAccount,
    isCreating,
    isUpdating 
  } = useAccounts();
  
  const { messages, sendCommand, clearMessages, isConnected } = useChat();

  const connectedCount = accounts.filter(a => a.connectionStatus === "connected").length;
  const totalAccounts = accounts.length;

  const handleEdit = (account: MinecraftAccount) => {
    setEditingAccount(account);
    setIsFormOpen(true);
  };

  const handleFormSubmit = async (data: any) => {
    if (editingAccount) {
      await updateAccount({ ...data, id: editingAccount.id });
    } else {
      await createAccount(data);
    }
    setIsFormOpen(false);
    setEditingAccount(null);
  };

  const handleFormClose = (open: boolean) => {
    setIsFormOpen(open);
    if (!open) {
      setEditingAccount(null);
    }
  };

  const stats = [
    {
      title: "Total Accounts",
      value: totalAccounts,
      icon: Users,
      color: "from-emerald-500 to-emerald-600",
    },
    {
      title: "Connected",
      value: connectedCount,
      icon: Wifi,
      color: "from-cyan-500 to-cyan-600",
    },
    {
      title: "Messages",
      value: messages.length,
      icon: MessageSquare,
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "Uptime",
      value: "100%",
      icon: Activity,
      color: "from-amber-500 to-amber-600",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Manage your Minecraft console connections
          </p>
        </div>
        <motion.div
          animate={{ 
            boxShadow: connectedCount > 0 
              ? ["0 0 20px rgba(34, 197, 94, 0.3)", "0 0 40px rgba(34, 197, 94, 0.5)", "0 0 20px rgba(34, 197, 94, 0.3)"]
              : "none"
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="rounded-lg"
        >
          <Badge 
            variant={connectedCount > 0 ? "default" : "secondary"}
            className="px-4 py-2 text-sm"
          >
            <Zap className="w-4 h-4 mr-2" />
            {connectedCount > 0 ? `${connectedCount} Active` : "No Active Connections"}
          </Badge>
        </motion.div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="overflow-visible">
              <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid={`stat-${stat.title.toLowerCase().replace(" ", "-")}`}>
                  {stat.value}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Accounts</h2>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsFormOpen(true)}
              data-testid="button-add-account-header"
            >
              Add Account
            </Button>
          </div>
          
          <div className="grid gap-4 sm:grid-cols-2">
            {accounts.slice(0, 4).map((account) => (
              <AccountCard
                key={account.id}
                account={account}
                onLaunch={launchAccount}
                onStop={stopAccount}
                onEdit={handleEdit}
                onDelete={deleteAccount}
              />
            ))}
            {accounts.length < 4 && (
              <AddAccountCard onClick={() => setIsFormOpen(true)} />
            )}
          </div>
          
          {accounts.length > 4 && (
            <Button variant="ghost" className="w-full" asChild>
              <a href="/accounts">View all {accounts.length} accounts</a>
            </Button>
          )}
        </div>

        <div className="h-[400px]">
          <ChatConsole
            messages={messages.slice(-50)}
            onSendCommand={sendCommand}
            onClear={clearMessages}
            isConnected={isConnected}
          />
        </div>
      </div>

      <AccountForm
        open={isFormOpen}
        onOpenChange={handleFormClose}
        account={editingAccount}
        onSubmit={handleFormSubmit}
        isLoading={isCreating || isUpdating}
      />
    </div>
  );
}
