import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Settings as SettingsIcon,
  Palette,
  RefreshCw,
  Globe,
  Terminal,
  Save,
  Gamepad2,
  Moon,
  Sun
} from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import { useTheme } from "@/hooks/use-theme";
import { MINECRAFT_VERSIONS } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  
  const [defaultVersion, setDefaultVersion] = useState("1.20.4");
  const [autoReconnect, setAutoReconnect] = useState(true);
  const [reconnectDelay, setReconnectDelay] = useState("5000");
  const [acceptTextures, setAcceptTextures] = useState(true);

  const handleSave = () => {
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const settingsSections = [
    {
      id: "appearance",
      title: "Appearance",
      description: "Customize the look and feel of the launcher",
      icon: Palette,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Theme</Label>
              <p className="text-sm text-muted-foreground">
                Choose between light and dark mode
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={theme === "light" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("light")}
                data-testid="button-theme-light"
              >
                <Sun className="w-4 h-4 mr-2" />
                Light
              </Button>
              <Button
                variant={theme === "dark" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("dark")}
                data-testid="button-theme-dark"
              >
                <Moon className="w-4 h-4 mr-2" />
                Dark
              </Button>
            </div>
          </div>
        </div>
      ),
    },
    {
      id: "defaults",
      title: "Default Settings",
      description: "Set default values for new accounts",
      icon: SettingsIcon,
      content: (
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Default Minecraft Version</Label>
              <Select value={defaultVersion} onValueChange={setDefaultVersion}>
                <SelectTrigger data-testid="select-default-version">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-64">
                  {MINECRAFT_VERSIONS.map((version) => (
                    <SelectItem key={version} value={version}>
                      {version}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Reconnect Delay (ms)</Label>
              <Input
                type="number"
                value={reconnectDelay}
                onChange={(e) => setReconnectDelay(e.target.value)}
                placeholder="5000"
                data-testid="input-default-reconnect-delay"
              />
            </div>
          </div>
        </div>
      ),
    },
    {
      id: "connection",
      title: "Connection Settings",
      description: "Configure connection behavior",
      icon: RefreshCw,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label>Auto-Reconnect by Default</Label>
              <p className="text-sm text-muted-foreground">
                Automatically reconnect when connection is lost
              </p>
            </div>
            <Switch
              checked={autoReconnect}
              onCheckedChange={setAutoReconnect}
              data-testid="switch-default-auto-reconnect"
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label>Accept Resource Packs by Default</Label>
              <p className="text-sm text-muted-foreground">
                Automatically accept server resource packs
              </p>
            </div>
            <Switch
              checked={acceptTextures}
              onCheckedChange={setAcceptTextures}
              data-testid="switch-default-accept-textures"
            />
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground mt-1">
            Configure your launcher preferences
          </p>
        </div>
        <Button 
          onClick={handleSave}
          className="bg-gradient-to-r from-emerald-600 to-cyan-600"
          data-testid="button-save-settings"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Changes
        </Button>
      </div>

      <div className="space-y-6">
        {settingsSections.map((section, index) => (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-600/20 to-cyan-600/20 flex items-center justify-center">
                    <section.icon className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <CardTitle>{section.title}</CardTitle>
                    <CardDescription>{section.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>{section.content}</CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-600/20 to-cyan-600/20 flex items-center justify-center">
              <Gamepad2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <CardTitle>About</CardTitle>
              <CardDescription>MC Console Launcher information</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Version</span>
            <Badge variant="secondary">1.0.0</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Built with</span>
            <span className="text-sm">React + Mineflayer</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Supported Versions</span>
            <span className="text-sm">1.8 - 1.21.4</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
