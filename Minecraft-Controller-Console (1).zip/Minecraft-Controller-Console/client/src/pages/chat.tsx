import { useState } from "react";
import { ChatConsole } from "@/components/chat-console";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  MessageSquare, 
  Users, 
  Wifi,
  Terminal,
  History
} from "lucide-react";
import { motion } from "framer-motion";
import { useAccounts } from "@/hooks/use-accounts";
import { useChat } from "@/hooks/use-chat";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function Chat() {
  const { accounts } = useAccounts();
  const { messages, sendCommand, clearMessages, isConnected, selectedAccountId, setSelectedAccountId } = useChat();
  
  const connectedAccounts = accounts.filter(a => a.connectionStatus === "connected");
  const selectedAccount = accounts.find(a => a.id === selectedAccountId);

  const accountMessages = selectedAccountId 
    ? messages.filter(m => m.accountId === selectedAccountId)
    : messages;

  return (
    <div className="h-full flex flex-col space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Chat Viewer</h1>
          <p className="text-muted-foreground mt-1">
            Monitor all chat messages in real-time
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="px-3 py-1">
            <MessageSquare className="w-4 h-4 mr-2" />
            {messages.length} Messages
          </Badge>
          <Badge 
            variant={connectedAccounts.length > 0 ? "default" : "secondary"}
            className="px-3 py-1"
          >
            <Wifi className="w-4 h-4 mr-2" />
            {connectedAccounts.length} Connected
          </Badge>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-4 flex-1 min-h-0">
        <div className="lg:col-span-3 h-full min-h-[500px]">
          <ChatConsole
            messages={accountMessages}
            onSendCommand={sendCommand}
            onClear={clearMessages}
            isConnected={isConnected && !!selectedAccountId}
          />
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="w-4 h-4" />
                Select Account
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {connectedAccounts.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">
                  <Wifi className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No connected accounts</p>
                  <p className="text-xs mt-1">Connect an account to start chatting</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {connectedAccounts.map((account) => (
                    <motion.div
                      key={account.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button
                        variant={selectedAccountId === account.id ? "default" : "ghost"}
                        className={`w-full justify-start gap-3 ${
                          selectedAccountId === account.id 
                            ? "bg-gradient-to-r from-emerald-600 to-cyan-600" 
                            : ""
                        }`}
                        onClick={() => setSelectedAccountId(account.id)}
                        data-testid={`button-select-account-${account.id}`}
                      >
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="text-xs bg-muted">
                            {account.username.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="text-left">
                          <p className="text-sm font-medium">{account.username}</p>
                          <p className="text-xs opacity-70">{account.serverHost}</p>
                        </div>
                      </Button>
                    </motion.div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {selectedAccount && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Terminal className="w-4 h-4" />
                    Session Info
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Account</span>
                    <span className="font-medium">{selectedAccount.username}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Server</span>
                    <span className="font-medium truncate max-w-[120px]">
                      {selectedAccount.serverHost || "N/A"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Version</span>
                    <span className="font-medium">{selectedAccount.version}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Messages</span>
                    <span className="font-medium">{accountMessages.length}</span>
                  </div>
                  {selectedAccount.proxyEnabled && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Proxy</span>
                      <Badge variant="outline" className="text-xs">Active</Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <History className="w-4 h-4" />
                Quick Commands
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {["/help", "/list", "/spawn", "/home"].map((cmd) => (
                <Button
                  key={cmd}
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start font-mono text-xs"
                  onClick={() => sendCommand(cmd)}
                  disabled={!isConnected || !selectedAccountId}
                  data-testid={`button-quick-command-${cmd.slice(1)}`}
                >
                  {cmd}
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
