import { z } from "zod";

export const accountTypeSchema = z.enum(["offline", "online"]);
export type AccountType = z.infer<typeof accountTypeSchema>;

export const connectionStatusSchema = z.enum([
  "disconnected",
  "connecting",
  "connected",
  "reconnecting"
]);
export type ConnectionStatus = z.infer<typeof connectionStatusSchema>;

export const minecraftAccountSchema = z.object({
  id: z.string(),
  username: z.string().min(1).max(16),
  accountType: accountTypeSchema,
  accessToken: z.string().optional(),
  version: z.string().default("1.20.4"),
  serverHost: z.string().optional(),
  serverPort: z.number().default(25565),
  proxyEnabled: z.boolean().default(false),
  proxyHost: z.string().optional(),
  proxyPort: z.number().optional(),
  proxyType: z.enum(["socks5", "http"]).optional(),
  autoReconnect: z.boolean().default(true),
  reconnectDelay: z.number().default(5000),
  autoCommands: z.array(z.string()).default([]),
  acceptTextures: z.boolean().default(true),
  connectionStatus: connectionStatusSchema.default("disconnected"),
});

export type MinecraftAccount = z.infer<typeof minecraftAccountSchema>;

export const insertAccountSchema = minecraftAccountSchema.omit({ id: true, connectionStatus: true });
export type InsertAccount = z.infer<typeof insertAccountSchema>;

export const updateAccountSchema = minecraftAccountSchema.omit({ id: true, connectionStatus: true }).partial();
export type UpdateAccount = z.infer<typeof updateAccountSchema>;

export const commandSchema = z.object({
  command: z.string().min(1, "Command is required"),
});
export type CommandPayload = z.infer<typeof commandSchema>;

export const chatMessageSchema = z.object({
  id: z.string(),
  accountId: z.string(),
  timestamp: z.number(),
  sender: z.string(),
  message: z.string(),
  type: z.enum(["chat", "system", "whisper", "action"]).default("chat"),
});

export type ChatMessage = z.infer<typeof chatMessageSchema>;

export const configSchema = z.object({
  defaultVersion: z.string().default("1.20.4"),
  defaultAutoReconnect: z.boolean().default(true),
  defaultReconnectDelay: z.number().default(5000),
  defaultAcceptTextures: z.boolean().default(true),
});

export type Config = z.infer<typeof configSchema>;

export const MINECRAFT_VERSIONS = [
  "1.21.4",
  "1.21.3", 
  "1.21.2",
  "1.21.1",
  "1.21",
  "1.20.6",
  "1.20.4",
  "1.20.3",
  "1.20.2",
  "1.20.1",
  "1.20",
  "1.19.4",
  "1.19.3",
  "1.19.2",
  "1.19.1",
  "1.19",
  "1.18.2",
  "1.18.1",
  "1.18",
  "1.17.1",
  "1.17",
  "1.16.5",
  "1.16.4",
  "1.16.3",
  "1.16.2",
  "1.16.1",
  "1.16",
  "1.15.2",
  "1.15.1",
  "1.15",
  "1.14.4",
  "1.14.3",
  "1.14.2",
  "1.14.1",
  "1.14",
  "1.13.2",
  "1.13.1",
  "1.13",
  "1.12.2",
  "1.12.1",
  "1.12",
  "1.11.2",
  "1.11.1",
  "1.11",
  "1.10.2",
  "1.10.1",
  "1.10",
  "1.9.4",
  "1.9.3",
  "1.9.2",
  "1.9.1",
  "1.9",
  "1.8.9",
  "1.8.8",
  "1.8.7",
  "1.8.6",
  "1.8.5",
  "1.8.4",
  "1.8.3",
  "1.8.2",
  "1.8.1",
  "1.8",
] as const;

export type User = {
  id: string;
  username: string;
  password: string;
};

export type InsertUser = Omit<User, "id">;
