import { randomUUID } from "crypto";
import type { MinecraftAccount, InsertAccount, ChatMessage, ConnectionStatus } from "@shared/schema";

export interface IStorage {
  getAccounts(): Promise<MinecraftAccount[]>;
  getAccount(id: string): Promise<MinecraftAccount | undefined>;
  createAccount(account: InsertAccount): Promise<MinecraftAccount>;
  updateAccount(id: string, account: Partial<MinecraftAccount>): Promise<MinecraftAccount | undefined>;
  deleteAccount(id: string): Promise<boolean>;
  updateConnectionStatus(id: string, status: ConnectionStatus): Promise<void>;
}

export class MemStorage implements IStorage {
  private accounts: Map<string, MinecraftAccount>;

  constructor() {
    this.accounts = new Map();
  }

  async getAccounts(): Promise<MinecraftAccount[]> {
    return Array.from(this.accounts.values());
  }

  async getAccount(id: string): Promise<MinecraftAccount | undefined> {
    return this.accounts.get(id);
  }

  async createAccount(insertAccount: InsertAccount): Promise<MinecraftAccount> {
    const id = randomUUID();
    const account: MinecraftAccount = {
      id,
      username: insertAccount.username,
      accountType: insertAccount.accountType || "offline",
      version: insertAccount.version || "1.20.4",
      serverHost: insertAccount.serverHost,
      serverPort: insertAccount.serverPort || 25565,
      proxyEnabled: insertAccount.proxyEnabled || false,
      proxyHost: insertAccount.proxyHost,
      proxyPort: insertAccount.proxyPort,
      proxyType: insertAccount.proxyType,
      autoReconnect: insertAccount.autoReconnect ?? true,
      reconnectDelay: insertAccount.reconnectDelay || 5000,
      autoCommands: insertAccount.autoCommands || [],
      acceptTextures: insertAccount.acceptTextures ?? true,
      connectionStatus: "disconnected",
    };
    this.accounts.set(id, account);
    return account;
  }

  async updateAccount(id: string, data: Partial<MinecraftAccount>): Promise<MinecraftAccount | undefined> {
    const existing = this.accounts.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...data, id };
    this.accounts.set(id, updated);
    return updated;
  }

  async deleteAccount(id: string): Promise<boolean> {
    return this.accounts.delete(id);
  }

  async updateConnectionStatus(id: string, status: ConnectionStatus): Promise<void> {
    const account = this.accounts.get(id);
    if (account) {
      account.connectionStatus = status;
      this.accounts.set(id, account);
    }
  }
}

export const storage = new MemStorage();
