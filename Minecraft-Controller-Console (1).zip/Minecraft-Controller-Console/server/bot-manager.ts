import mineflayer from "mineflayer";
import { SocksClient } from "socks";
import { storage } from "./storage";
import type { MinecraftAccount, ChatMessage } from "@shared/schema";
import type { WebSocket } from "ws";

interface BotInstance {
  bot: mineflayer.Bot;
  accountId: string;
  reconnectTimeout?: NodeJS.Timeout;
}

class BotManager {
  private bots: Map<string, BotInstance> = new Map();
  private wsClients: Set<WebSocket> = new Set();

  addWsClient(ws: WebSocket) {
    this.wsClients.add(ws);
  }

  removeWsClient(ws: WebSocket) {
    this.wsClients.delete(ws);
  }

  private broadcast(data: any) {
    const message = JSON.stringify(data);
    this.wsClients.forEach((ws) => {
      if (ws.readyState === 1) {
        ws.send(message);
      }
    });
  }

  async launchBot(account: MinecraftAccount): Promise<void> {
    if (this.bots.has(account.id)) {
      await this.stopBot(account.id);
    }

    await storage.updateConnectionStatus(account.id, "connecting");
    this.broadcast({
      type: "status",
      accountId: account.id,
      status: "connecting",
      username: account.username,
    });

    try {
      if (!account.serverHost) {
        throw new Error("Server host is required");
      }

      const botOptions: mineflayer.BotOptions = {
        host: account.serverHost,
        port: account.serverPort || 25565,
        username: account.username,
        version: account.version,
        auth: account.accountType === "online" ? "microsoft" : "offline",
        hideErrors: true,
      };

      if (account.proxyEnabled && account.proxyHost && account.proxyPort) {
        const proxyInfo = await SocksClient.createConnection({
          proxy: {
            host: account.proxyHost,
            port: account.proxyPort,
            type: account.proxyType === "socks5" ? 5 : 4,
          },
          command: "connect",
          destination: {
            host: account.serverHost,
            port: account.serverPort || 25565,
          },
        });
        
        (botOptions as any).connect = (client: any) => {
          client.setSocket(proxyInfo.socket);
          client.emit("connect");
        };
      }

      const bot = mineflayer.createBot(botOptions);

      bot.on("spawn", async () => {
        await storage.updateConnectionStatus(account.id, "connected");
        this.broadcast({
          type: "status",
          accountId: account.id,
          status: "connected",
          username: account.username,
          server: account.serverHost,
        });

        if (account.autoCommands && account.autoCommands.length > 0) {
          for (let i = 0; i < account.autoCommands.length; i++) {
            const cmd = account.autoCommands[i];
            setTimeout(() => {
              bot.chat(cmd);
            }, (i + 1) * 1000);
          }
        }
      });

      bot.on("message", (jsonMsg: any) => {
        const message = jsonMsg.toString();
        if (message.trim()) {
          this.broadcast({
            type: "chat",
            accountId: account.id,
            timestamp: Date.now(),
            sender: "Server",
            message: message,
            messageType: "chat",
          });
        }
      });

      bot.on("whisper", (username: string, message: string) => {
        this.broadcast({
          type: "chat",
          accountId: account.id,
          timestamp: Date.now(),
          sender: username,
          message: message,
          messageType: "whisper",
        });
      });

      if (account.acceptTextures) {
        bot.on("resourcePack" as any, (url: string, hash: string) => {
          (bot as any).acceptResourcePack();
        });
      }

      bot.on("kicked", async (reason: string) => {
        await storage.updateConnectionStatus(account.id, "disconnected");
        this.broadcast({
          type: "status",
          accountId: account.id,
          status: "disconnected",
          reason: `Kicked: ${reason}`,
        });

        this.bots.delete(account.id);

        if (account.autoReconnect) {
          this.scheduleReconnect(account);
        }
      });

      bot.on("end", async (reason: string) => {
        await storage.updateConnectionStatus(account.id, "disconnected");
        this.broadcast({
          type: "status",
          accountId: account.id,
          status: "disconnected",
          reason: reason || "Connection ended",
        });

        this.bots.delete(account.id);

        if (account.autoReconnect) {
          this.scheduleReconnect(account);
        }
      });

      bot.on("error", async (error: Error) => {
        console.error(`Bot error for ${account.username}:`, error.message);
        this.broadcast({
          type: "chat",
          accountId: account.id,
          timestamp: Date.now(),
          sender: "System",
          message: `Error: ${error.message}`,
          messageType: "system",
        });
      });

      this.bots.set(account.id, { bot, accountId: account.id });

    } catch (error: any) {
      await storage.updateConnectionStatus(account.id, "disconnected");
      this.broadcast({
        type: "status",
        accountId: account.id,
        status: "disconnected",
        reason: error.message,
      });
      throw error;
    }
  }

  private scheduleReconnect(account: MinecraftAccount) {
    const delay = account.reconnectDelay || 5000;
    
    this.broadcast({
      type: "chat",
      accountId: account.id,
      timestamp: Date.now(),
      sender: "System",
      message: `Reconnecting in ${delay / 1000} seconds...`,
      messageType: "system",
    });

    setTimeout(async () => {
      const currentAccount = await storage.getAccount(account.id);
      if (currentAccount && currentAccount.autoReconnect) {
        try {
          await storage.updateConnectionStatus(account.id, "reconnecting");
          this.broadcast({
            type: "status",
            accountId: account.id,
            status: "reconnecting",
          });
          await this.launchBot(currentAccount);
        } catch (error) {
          console.error(`Reconnect failed for ${account.username}`);
        }
      }
    }, delay);
  }

  async stopBot(accountId: string): Promise<void> {
    const instance = this.bots.get(accountId);
    if (instance) {
      if (instance.reconnectTimeout) {
        clearTimeout(instance.reconnectTimeout);
      }
      
      const account = await storage.getAccount(accountId);
      if (account) {
        await storage.updateAccount(accountId, { autoReconnect: false });
      }
      
      instance.bot.quit();
      this.bots.delete(accountId);
      await storage.updateConnectionStatus(accountId, "disconnected");
      
      if (account) {
        await storage.updateAccount(accountId, { autoReconnect: account.autoReconnect });
      }
      
      this.broadcast({
        type: "status",
        accountId,
        status: "disconnected",
        reason: "Stopped by user",
      });
    }
  }

  sendCommand(accountId: string, command: string): boolean {
    const instance = this.bots.get(accountId);
    if (instance && instance.bot) {
      instance.bot.chat(command);
      return true;
    }
    return false;
  }

  getConnectedAccounts(): string[] {
    return Array.from(this.bots.keys());
  }
}

export const botManager = new BotManager();
